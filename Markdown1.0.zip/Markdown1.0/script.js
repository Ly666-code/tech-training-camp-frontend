"use strict";

const codeSpace = document.getElementById("code");
const renderpage = document.getElementById("renderpage");
const btn = document.getElementById("get");
let codeVal;

function process(){
    codeVal = codeSpace.value;
    codeVal = codeVal.replace(/<(.*)>/gm, "<a href=\"$1\">$1</a>"); // 匹配链接
    for(let i=1; i<=6; ++i){
        const reg = new RegExp(`^(#{${i}}) +(.*)`, "gm");
        codeVal = codeVal.replace(reg, `<h${i}>$2</h${i}>`);
    } // 匹配标题
    codeVal = codeVal.replace(/(.*)  $/gm, "<p>$1</p>"); // 匹配段落
    codeVal = codeVal.replace(/^[-*+] +([^*\n]*)/gm, "<li>$1</li>"); // 匹配无序列表
    codeVal = codeVal.replace(/(^[1-9])\. +(.*)/gm, "<p>$1. $2</p>"); // 匹配有序列表
    codeVal = codeVal.replace(/> +(.*)/gm, "<blockquote>$1</blockquote>"); // 匹配引用
    

    // 匹配完所有结构性标签后再匹配文字格式类标签
    codeVal = codeVal.replace(/^[*_]{3}([^*\n]*)[*_]{3}$/gm, "<i><b>$1</b></i>"); // 匹配粗斜体文字
    codeVal = codeVal.replace(/^[*_]{2}([^*\n]*)[*_]{2}$/gm, "<b>$1</b>"); // 匹配粗体文字
    codeVal = codeVal.replace(/^[*_]([^*\n]*)[*_]$/gm, "<i>$1</i>"); // 匹配斜体文字
    renderpage.innerHTML = codeVal; 
}
btn.addEventListener("click", process);

// # Markdown编辑器使用说明
// ## 项目简介
// 本项目是一个简易版Markdown编辑器，目前仅支持部分Markdown语法(说明见下方)，部分功能待完善。

// ## 支持Markdown语法概览
// - 标题1-6(仅支持#声明方式)
// - 段落(末尾增加两个空格)
// - 无序列表(以-、+、*开头跟一个空格)
// - 有序列表(以数字.形式开头)
// - 引用(以>开头加一个或一个以上空格)
// - 链接(仅支持<>定义格式)

// > 提示：目前仅支持以上语法格式，其他功能待完善

// ## 编辑器界面简介
// 编辑器采用左边编辑代码，右边显示的布局模式，中间设置一个转换按钮，点击即可转换为对应的html文件并显示  
// > 提示：本项目不采用实时渲染模式，需要用户点击转换按键进行手动转换


// # Markdown编辑器项目说明
// ## 解析器实现方式
// 由于本项目是一个简易版Markdown编辑器，使用正则表达式匹配模式进行Markdown格式转换
